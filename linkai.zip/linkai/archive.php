<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package AI_Consulting
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container py-4">
        <?php if (have_posts()) : ?>

            <header class="page-header mb-4">
                <?php
                the_archive_title('<h1 class="page-title">', '</h1>');
                the_archive_description('<div class="archive-description">', '</div>');
                ?>
            </header><!-- .page-header -->

            <?php
            /* Start the Loop */
            while (have_posts()) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('mb-4'); ?>>
                    <header class="entry-header">
                        <?php the_title(sprintf('<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url(get_permalink())), '</a></h2>'); ?>

                        <?php if ('post' === get_post_type()) : ?>
                            <div class="entry-meta">
                                <span class="posted-on">
                                    <?php echo esc_html(get_the_date()); ?>
                                </span>
                                <span class="byline">
                                    <?php esc_html_e('by', 'ai-consulting'); ?> <?php the_author(); ?>
                                </span>
                            </div><!-- .entry-meta -->
                        <?php endif; ?>
                    </header><!-- .entry-header -->

                    <?php if (has_post_thumbnail()) : ?>
                        <div class="post-thumbnail mb-3">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail('medium'); ?>
                            </a>
                        </div>
                    <?php endif; ?>

                    <div class="entry-summary">
                        <?php the_excerpt(); ?>
                        <a href="<?php echo esc_url(get_permalink()); ?>" class="read-more">
                            <?php esc_html_e('Read More', 'ai-consulting'); ?>
                        </a>
                    </div><!-- .entry-summary -->
                </article><!-- #post-<?php the_ID(); ?> -->
                <?php
            endwhile;

            the_posts_navigation();

        else :
            ?>
            <p><?php esc_html_e('No posts found.', 'ai-consulting'); ?></p>
            <?php
        endif;
        ?>
    </div>
</main><!-- #main -->

<?php
get_footer(); 