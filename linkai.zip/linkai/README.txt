=== AI Consulting ===
Contributors: aiconsulting
Requires at least: 5.0
Tested up to: 6.2
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: ai, consulting, business, modern, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready

A modern WordPress theme for AI consulting businesses.

== Description ==

AI Consulting is a clean, modern WordPress theme designed specifically for AI consulting businesses. It features a professional design with a focus on readability and user experience.

= Features =
* Responsive design
* Custom header
* Custom logo
* Custom colors
* Featured images
* Customizable footer
* Social media integration
* SEO optimized
* Translation ready

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

Alternatively:

1. Upload the `ai-consulting` folder to the `/wp-content/themes/` directory
2. Activate the theme through the 'Themes' menu in WordPress
3. Configure the theme settings through the WordPress Customizer

== Frequently Asked Questions ==

= Does this theme support any plugins? =

AI Consulting includes support for the following plugins:
* Jetpack
* Contact Form 7
* WooCommerce
* Advanced Custom Fields

= How do I set up the homepage? =

1. Create a new page
2. Go to Settings > Reading
3. Set "Your homepage displays" to "A static page"
4. Select the page you created as the Homepage

= How do I customize the theme? =

You can customize the theme through the WordPress Customizer. Go to Appearance > Customize to access the theme options.

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
* Initial release

== Resources ==

* Font Awesome: https://fontawesome.com/ (License: MIT, SIL OFL 1.1)
* Google Fonts: https://fonts.google.com/ (License: SIL OFL 1.1)
* Normalize.css: https://necolas.github.io/normalize.css/ (License: MIT)
* AOS: https://michalsnik.github.io/aos/ (License: MIT)

== Additional Notes ==

= Building CSS =
If you want to modify the CSS of the theme, you'll need to:
1. Install Node.js and npm
2. Run `npm install` in the theme directory
3. Run `npm run build` to compile the CSS
4. Run `npm run watch` to watch for changes and compile automatically

= Troubleshooting =
If you encounter any issues with the theme, please:
1. Check that you're using the latest version of WordPress
2. Check that you've activated the theme
3. Check that you've set up the theme correctly
4. Contact support if you're still having issues