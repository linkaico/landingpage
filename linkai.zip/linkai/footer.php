<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 */
?>

    </div><!-- #content -->

    <footer id="colophon" class="site-footer">
        <div class="container">
            <div class="footer-widgets">
                <div class="footer-widget-area">
                    <?php if (is_active_sidebar('footer-1')) : ?>
                        <?php dynamic_sidebar('footer-1'); ?>
                    <?php else : ?>
                        <div class="widget">
                            <h2 class="widget-title"><?php esc_html_e('About Us', 'ai-consulting'); ?></h2>
                            <p><?php echo esc_html(get_theme_mod('footer_text', esc_html__('AI Consulting is a modern WordPress theme for AI consulting businesses.', 'ai-consulting'))); ?></p>
                            <div class="social-links">
                                <?php if (get_theme_mod('linkedin_url')) : ?>
                                    <a href="<?php echo esc_url(get_theme_mod('linkedin_url')); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('LinkedIn', 'ai-consulting'); ?></a>
                                <?php endif; ?>
                                <?php if (get_theme_mod('twitter_url')) : ?>
                                    <a href="<?php echo esc_url(get_theme_mod('twitter_url')); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Twitter', 'ai-consulting'); ?></a>
                                <?php endif; ?>
                                <?php if (get_theme_mod('github_url')) : ?>
                                    <a href="<?php echo esc_url(get_theme_mod('github_url')); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('GitHub', 'ai-consulting'); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="footer-widget-area">
                    <?php if (is_active_sidebar('footer-2')) : ?>
                        <?php dynamic_sidebar('footer-2'); ?>
                    <?php else : ?>
                        <div class="widget">
                            <h2 class="widget-title"><?php esc_html_e('Quick Links', 'ai-consulting'); ?></h2>
                            <?php
                            wp_nav_menu(
                                array(
                                    'theme_location' => 'footer',
                                    'menu_id'        => 'footer-menu',
                                    'fallback_cb'    => false,
                                    'depth'          => 1,
                                )
                            );
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="footer-widget-area">
                    <?php if (is_active_sidebar('footer-3')) : ?>
                        <?php dynamic_sidebar('footer-3'); ?>
                    <?php else : ?>
                        <div class="widget">
                            <h2 class="widget-title"><?php esc_html_e('Contact Us', 'ai-consulting'); ?></h2>
                            <address>
                                <?php if (get_theme_mod('company_address')) : ?>
                                    <p><?php echo esc_html(get_theme_mod('company_address')); ?></p>
                                <?php endif; ?>
                                <?php if (get_theme_mod('company_phone')) : ?>
                                    <p><?php echo esc_html(get_theme_mod('company_phone')); ?></p>
                                <?php endif; ?>
                                <?php if (get_theme_mod('company_email')) : ?>
                                    <p><a href="mailto:<?php echo esc_attr(get_theme_mod('company_email')); ?>"><?php echo esc_html(get_theme_mod('company_email')); ?></a></p>
                                <?php endif; ?>
                            </address>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="site-info">
                <div class="copyright">
                    &copy; <?php echo esc_html(date('Y')); ?> <?php bloginfo('name'); ?>
                </div>
                <div class="footer-links">
                    <?php if (get_privacy_policy_url()) : ?>
                        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php esc_html_e('Privacy Policy', 'ai-consulting'); ?></a>
                    <?php endif; ?>
                </div>
            </div><!-- .site-info -->
        </div><!-- .container -->
    </footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html> 