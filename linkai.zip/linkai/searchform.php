<?php
/**
 * The template for displaying search forms
 *
 * @package AI_Consulting
 */
?>

<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
    <label class="screen-reader-text" for="search-field"><?php esc_html_e('Search for:', 'ai-consulting'); ?></label>
    <div class="search-form-container">
        <input type="search" id="search-field" class="search-field" placeholder="<?php echo esc_attr_x('Search &hellip;', 'placeholder', 'ai-consulting'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
        <button type="submit" class="search-submit"><?php echo esc_html_x('Search', 'submit button', 'ai-consulting'); ?></button>
    </div>
</form> 