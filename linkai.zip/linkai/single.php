<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package AI_Consulting
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container py-4">
        <?php
        while (have_posts()) :
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header mb-4">
                    <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
                    
                    <div class="entry-meta">
                        <span class="posted-on">
                            <?php echo esc_html(get_the_date()); ?>
                        </span>
                        <span class="byline">
                            <?php esc_html_e('by', 'ai-consulting'); ?> <?php the_author(); ?>
                        </span>
                    </div><!-- .entry-meta -->
                </header><!-- .entry-header -->

                <?php if (has_post_thumbnail()) : ?>
                    <div class="post-thumbnail mb-4">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>

                <div class="entry-content">
                    <?php
                    the_content();

                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links">' . esc_html__('Pages:', 'ai-consulting'),
                            'after'  => '</div>',
                        )
                    );
                    ?>
                </div><!-- .entry-content -->

                <footer class="entry-footer mt-4">
                    <?php
                    // Display categories
                    $categories_list = get_the_category_list(', ');
                    if ($categories_list) {
                        echo '<div class="cat-links mb-2">' . esc_html__('Categories: ', 'ai-consulting') . $categories_list . '</div>';
                    }

                    // Display tags
                    $tags_list = get_the_tag_list('', ', ');
                    if ($tags_list) {
                        echo '<div class="tags-links mb-2">' . esc_html__('Tags: ', 'ai-consulting') . $tags_list . '</div>';
                    }

                    // Edit link
                    edit_post_link(
                        sprintf(
                            wp_kses(
                                /* translators: %s: Name of current post. Only visible to screen readers */
                                __('Edit <span class="screen-reader-text">%s</span>', 'ai-consulting'),
                                array(
                                    'span' => array(
                                        'class' => array(),
                                    ),
                                )
                            ),
                            wp_kses_post(get_the_title())
                        ),
                        '<div class="edit-link">',
                        '</div>'
                    );
                    ?>
                </footer><!-- .entry-footer -->
            </article><!-- #post-<?php the_ID(); ?> -->

            <div class="post-navigation-container mt-4 mb-4">
                <div class="post-navigation">
                    <div class="nav-previous">
                        <?php previous_post_link('%link', '&larr; %title'); ?>
                    </div>
                    <div class="nav-next">
                        <?php next_post_link('%link', '%title &rarr;'); ?>
                    </div>
                </div>
            </div>

            <?php
            // If comments are open or we have at least one comment, load up the comment template.
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;

        endwhile; // End of the loop.
        ?>
    </div>
</main><!-- #main -->

<?php
get_footer(); 