<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package AI_Consulting
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container py-4">
        <?php if (have_posts()) : ?>

            <header class="page-header mb-4">
                <h1 class="page-title">
                    <?php
                    /* translators: %s: search query. */
                    printf(esc_html__('Search Results for: %s', 'ai-consulting'), '<span>' . get_search_query() . '</span>');
                    ?>
                </h1>
            </header><!-- .page-header -->

            <?php
            /* Start the Loop */
            while (have_posts()) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('mb-4'); ?>>
                    <header class="entry-header">
                        <?php the_title(sprintf('<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url(get_permalink())), '</a></h2>'); ?>

                        <?php if ('post' === get_post_type()) : ?>
                            <div class="entry-meta">
                                <span class="posted-on">
                                    <?php echo esc_html(get_the_date()); ?>
                                </span>
                                <span class="byline">
                                    <?php esc_html_e('by', 'ai-consulting'); ?> <?php the_author(); ?>
                                </span>
                            </div><!-- .entry-meta -->
                        <?php endif; ?>
                    </header><!-- .entry-header -->

                    <?php if (has_post_thumbnail()) : ?>
                        <div class="post-thumbnail mb-3">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail('medium'); ?>
                            </a>
                        </div>
                    <?php endif; ?>

                    <div class="entry-summary">
                        <?php the_excerpt(); ?>
                        <a href="<?php echo esc_url(get_permalink()); ?>" class="read-more">
                            <?php esc_html_e('Read More', 'ai-consulting'); ?>
                        </a>
                    </div><!-- .entry-summary -->
                </article><!-- #post-<?php the_ID(); ?> -->
                <?php
            endwhile;

            the_posts_navigation();

        else :
            ?>
            <header class="page-header mb-4">
                <h1 class="page-title">
                    <?php
                    /* translators: %s: search query. */
                    printf(esc_html__('Search Results for: %s', 'ai-consulting'), '<span>' . get_search_query() . '</span>');
                    ?>
                </h1>
            </header><!-- .page-header -->

            <p><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'ai-consulting'); ?></p>
            <?php
            get_search_form();

        endif;
        ?>
    </div>
</main><!-- #main -->

<?php
get_footer(); 