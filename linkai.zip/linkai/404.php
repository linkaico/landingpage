<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package AI_Consulting
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container py-4">
        <section class="error-404 not-found text-center py-5">
            <header class="page-header">
                <h1 class="page-title"><?php esc_html_e('Oops! That page can&rsquo;t be found.', 'ai-consulting'); ?></h1>
            </header><!-- .page-header -->

            <div class="page-content">
                <p><?php esc_html_e('It looks like nothing was found at this location. Maybe try a search?', 'ai-consulting'); ?></p>

                <?php get_search_form(); ?>

                <div class="mt-4">
                    <h2><?php esc_html_e('Here are some helpful links:', 'ai-consulting'); ?></h2>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'ai-consulting'); ?></a></li>
                        <?php
                        // Display a few recent posts
                        $recent_posts = wp_get_recent_posts(array(
                            'numberposts' => 5,
                            'post_status' => 'publish'
                        ));
                        
                        foreach ($recent_posts as $recent) {
                            echo '<li><a href="' . esc_url(get_permalink($recent['ID'])) . '">' . esc_html($recent['post_title']) . '</a></li>';
                        }
                        wp_reset_postdata();
                        ?>
                    </ul>
                </div>
            </div><!-- .page-content -->
        </section><!-- .error-404 -->
    </div>
</main><!-- #main -->

<?php
get_footer(); 